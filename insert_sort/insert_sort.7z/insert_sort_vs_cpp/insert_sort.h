#ifndef _INSERT_SORT_H_
#define _INSERT_SORT_H_

#define SIZE 1000

typedef int DTYPE;

void insert_sort(DTYPE A[SIZE], int Len);

#endif
