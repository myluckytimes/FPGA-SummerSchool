#include <stdio.h>
#include <stdlib.h>
#include <time.h>
#include "insert_sort.h"

int main()
{
	//产生一组随机整数
    DTYPE a[SIZE];
    srand(time(NULL));
    for (int i = 0; i < SIZE; i++) 
    {
        a[i] = rand() % 10000;
    }

    insert_sort(a, sizeof(a)/sizeof(a[0]));


    FILE *fp = fopen("./sorted.txt", "w");
    for(int i = 0; i < SIZE; i++)
    {
    	fprintf(fp, "%d\n", a[i]);
    }


    return 0;
}
