#include <stdio.h>
#include "insert_sort.h"


void insert_sort(DTYPE A[SIZE], int Len) {
#pragma HLS INTERFACE m_axi port=A offset=slave
#pragma HLS INTERFACE s_axilite port=Len  bundle=CTRL
#pragma HLS INTERFACE s_axilite port=return bundle=CTRL
#pragma HLS dataflow
L1:
    for (int i = 1; i < Len; i++) {
	#pragma HLS pipeline II=1
		int j = i;
		L2:
		for ( ; j > 0; j--) {
		#pragma HLS unroll factor=3
			if (A[j]<A[j-1]) {
				DTYPE tmp = A[j];
				A[j] = A[j - 1];
				A[j - 1] = tmp;
			}
		}
    }
}

